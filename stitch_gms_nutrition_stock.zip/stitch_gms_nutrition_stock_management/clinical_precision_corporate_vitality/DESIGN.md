---
name: Clinical Precision & Corporate Vitality
colors:
  surface: '#f5fcef'
  surface-dim: '#d5dcd0'
  surface-bright: '#f5fcef'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff6e9'
  surface-container: '#e9f0e4'
  surface-container-high: '#e3eade'
  surface-container-highest: '#dee5d9'
  on-surface: '#171d16'
  on-surface-variant: '#3f4a3c'
  inverse-surface: '#2c322a'
  inverse-on-surface: '#ecf3e7'
  outline: '#6f7a6b'
  outline-variant: '#becab8'
  surface-tint: '#006e1e'
  primary: '#00691c'
  on-primary: '#ffffff'
  primary-container: '#038527'
  on-primary-container: '#ebffe4'
  inverse-primary: '#70dd73'
  secondary: '#40683e'
  on-secondary: '#ffffff'
  secondary-container: '#c1efba'
  on-secondary-container: '#466e44'
  tertiary: '#a32b5a'
  on-tertiary: '#ffffff'
  tertiary-container: '#c34472'
  on-tertiary-container: '#fff7f7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#8cfb8c'
  primary-fixed-dim: '#70dd73'
  on-primary-fixed: '#002204'
  on-primary-fixed-variant: '#005314'
  secondary-fixed: '#c1efba'
  secondary-fixed-dim: '#a5d29f'
  on-secondary-fixed: '#002204'
  on-secondary-fixed-variant: '#284f28'
  tertiary-fixed: '#ffd9e1'
  tertiary-fixed-dim: '#ffb1c6'
  on-tertiary-fixed: '#3f001b'
  on-tertiary-fixed-variant: '#891346'
  background: '#f5fcef'
  on-background: '#171d16'
  surface-variant: '#dee5d9'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.025em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-tier corporate and clinical presence tailored to B2B nutraceutical distribution, regulatory partners, and institutional healthcare clients. The personality balances scientific rigor with bio-nutritional vitality: authoritative, sterile without being cold, and deeply reliable.

The visual aesthetic synthesizes **Corporate Modernism** with clean **Clinical Precision**:
- Generous micro and macro whitespace conveying pharmaceutical clarity and institutional purity.
- Structured data presentation prioritizing traceability, batch analytics, compliance specs, and product authenticity.
- Crisp structural lines combined with softened edges to bridge industrial chemical reliability with human wellness.
- High functional clarity designed to evoke total confidence, regulatory compliance, and scientific leadership.

## Colors

The palette grounds the interface in verified bio-science and institutional authority:

- **Primary (`#108A2B` - Bio-Emerald):** Represents human vitality, organic synthesis, and purity. Used for key call-to-actions, verified state indicators, active tabs, and primary metrics.
- **Secondary (`#588155` - Deep Corporate Olive):** Anchors trust, enterprise governance, and global supply logistics. Applied to primary headings, corporate navigation bars, structural accents, and high-priority data points.
- **Tertiary (`#C34472` - Clinical Rose):** Supplies energy and interactive focus. Used for secondary interaction states, informational badges, technical highlights, and dynamic chart series.
- **Neutral Palette:**
  - Base Background: `#F8FAFC` (Slate 50) delivers an ultra-clean, clinical canvas with zero visual glare.
  - Surface Elevated: `#FFFFFF` for cards, modals, and data panels.
  - Surface Subdued: `#F1F5F9` (Slate 100) for nested containers, table headers, and disabled states.
  - Border System: `#E2E8F0` (Slate 200) for razor-thin separation, scaling to `#CBD5E1` for input field perimeters.
  - Typography: Primary text sits at `#0F172A` (Slate 900) for absolute legibility; secondary body sits at `#475569` (Slate 600); captions and helper text sit at `#64748B` (Slate 500).
- **Functional Semantics:**
  - Success/Certified: `#059669` (Emerald 600)
  - Warning/Batch Hold: `#D97706` (Amber 600)
  - Error/Non-Compliant: `#DC2626` (Red 600)
  - Info/Traceability: `#0284C7` (Sky 600)

## Typography

**Plus Jakarta Sans** is the single typographic voice across headlines, body copy, and UI controls. Its geometric clarity combined with subtle humanistic curves matches the dual requirements of scientific formulation and high-value corporate operations:

- **Headlines & Section Titles:** Emphasize deliberate hierarchy using weights 600 and 700 with negative tracking to ensure compact, confident framing.
- **Data & Body Copy:** Set with generous line heights to facilitate prolonged reading of nutritional certificates, chemical specifications, and shipping manifests.
- **Labels & Microcopy:** Rendered with elevated weights (600) and slight positive tracking to ensure fast legibility on high-density inventory monitors and laboratory dashboards.
- **Numerical Alignment:** Monospaced lining figures (`font-variant-numeric: tabular-nums`) must be enforced for batch numbers, volumetric units, pricing, and chemical percentages.

## Layout & Spacing

The layout philosophy follows a **12-column responsive fluid-to-fixed grid** engineered around structured inventory and clinical specification displays:

- **Desktop (≥ 1280px):** 12-column layout, bounded to a maximum width of 1440px. Gutters stay fixed at `1.5rem` (24px) with dynamic outer margins matching `2rem` (32px) or centered padding.
- **Tablet (768px – 1279px):** 8-column layout with `1.5rem` gutters and `1.5rem` margins. Complex analytical dashboards fold into stacked cards.
- **Mobile (< 768px):** 4-column layout with `1rem` (16px) gutters and `1rem` margins. Tables transform into collapsible list items.

### Spacing Philosophy
- Base layout rhythm operates on a crisp **4px/8px modular base unit**.
- Component interior padding relies on compact density: `space-xs` (4px) for inline status tags, `space-sm` (8px) for compact cell padding, `space-md` (16px) for standard cards and form controls, `space-lg` (24px) for major modular groups, and `space-xl` (40px) for macro section separation.

## Elevation & Depth

Visual hierarchy rejects exaggerated drop shadows in favor of **Tonal Layering**, **Crisp 1px Borders**, and **Micro Ambient Glows**:

- **Border-First Architecture:** Every elevation layer utilizes a baseline structural stroke of `1px solid #E2E8F0`. This establishes an analytical, laboratory-grade division between panels.
- **Level 0 (Flat Canvas):** `#F8FAFC` background. Completely flat, anchoring content with negative space.
- **Level 1 (Resting Cards & Surfaces):** `#FFFFFF` surface paired with `1px solid #E2E8F0` and a diffuse ambient shadow:
  `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Hover States, Interactive Cards, Floating Tooltips):** `#FFFFFF` surface with an elevated ambient drop:
  `box-shadow: 0 4px 6px -1px rgba(16, 138, 43, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`, alongside a border transition to `#CBD5E1`.
- **Level 3 (Modals, Overlays, Dropdowns):** `#FFFFFF` surface with deep focus projection:
  `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

The design system employs a **Rounded** shape model (`roundedness: 2`), implementing calibrated geometric radii between 8px and 12px:

- **Standard Elements (8px / `rounded-md`):** Buttons, input fields, dropdown trigger buttons, table rows, and alert banners. Maintains a compact, precise corporate feel.
- **Structural Containers (12px to 16px / `rounded-lg` to `rounded-xl`):** Primary cards, analytical widgets, modal dialogue frames, and data dashboards.
- **Micro UI & Pills (9999px / `rounded-full`):** Exclusively reserved for status chips, chemical batch validation tags, avatar circles, and quantitative counts.

## Components

### Buttons
- **Primary:** Background `#108A2B`, text `#FFFFFF`, border `1px solid transparent`, border-radius 8px. Hover: `#0e7524`. Active: `#0b5e1d`. Focus ring: 2px offset with `#C34472`.
- **Secondary (Corporate):** Background `#588155`, text `#FFFFFF`. Hover: `#4a6e47`.
- **Outline/Clinical:** Background `#FFFFFF`, text `#108A2B`, border `1px solid #108A2B`. Hover: Background `#F0FDFA`.
- **Ghost/Tertiary:** Background transparent, text `#475569`. Hover: Background `#F1F5F9`, text `#0F172A`.

### Cards & Data Panels
- Pure white background (`#FFFFFF`), perimeter border `1px solid #E2E8F0`, corner radius `12px`.
- Internal padding is set to `24px` (`space-lg`).
- Header areas feature a subtle divider border (`#F1F5F9`) separating title groupings and action buttons from data tables.

### Input Fields & Selects
- Surface `#FFFFFF`, border `1px solid #CBD5E1`, border-radius 8px, padding `10px 14px`.
- Typography: `body-md` (`#0F172A`), placeholder `#94A3B8`.
- Focus State: Border color `#108A2B` with a subtle ring: `0 0 0 3px rgba(16, 138, 43, 0.12)`.

### Chips & Badges
- **Batch Validated / Certified:** Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`, rounded full, padding `4px 10px`, typography `label-sm`.
- **Corporate Blue Tag:** Background `#EFF6FF`, text `#1E40AF`, border `1px solid #BFDBFE`.
- **Nutritional Grade / Technical:** Background `#F8FAFC`, text `#475569`, border `1px solid #E2E8F0`.

### Tables (B2B Catalogs & Specifications)
- Table headers: Background `#F8FAFC`, text `#64748B`, typography `label-sm`, uppercase, letter spacing `0.05em`, border bottom `1px solid #E2E8F0`.
- Rows: Background `#FFFFFF`, border bottom `1px solid #F1F5F9`. Hover state transitions to `#F8FAFC`.
- Cells: Padding `12px 16px`, numeric columns aligned right with monospaced tabular numerals.

### Checkboxes & Radios
- Size 18px × 18px, border `1.5px solid #94A3B8`, rounded 4px (checkbox) or circular (radio).
- Checked State: Fill `#108A2B`, icon `#FFFFFF`, border color `#108A2B`.